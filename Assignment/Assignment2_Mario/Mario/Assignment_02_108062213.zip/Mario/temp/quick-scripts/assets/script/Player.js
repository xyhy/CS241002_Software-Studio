(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/Player.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dfb2eo3lO5MwqbzLMYDX92/', 'Player', __filename);
// script/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.playerSpeed = 0;
        _this.gameMgr = null;
        _this.lifect = null;
        //private idleFrame: cc.SpriteFrame = null;
        _this.anim = null;
        _this.up = false;
        _this.down = false;
        _this.left = false;
        _this.right = false;
        _this.onGround = false;
        _this.isDead = false;
        _this.isBig = false;
        _this.rebornPosition = cc.v2(200, 50);
        _this.A = 40;
        _this.coins = 0;
        _this.scores = 0;
        _this.life = 0;
        return _this;
    }
    Player.prototype.onLoad = function () {
        this.anim = this.getComponent("cc.Animation");
        cc.director.getPhysicsManager().enabled = true;
        this.anim = this.getComponent(cc.Animation);
    };
    Player.prototype.start = function () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        this.reborn();
    };
    Player.prototype.update = function (dt) {
        this.playerMovement(dt);
        this.playerAnimation();
    };
    Player.prototype.onKeyDown = function (event) {
        if (event.keyCode == cc.macro.KEY.left) {
            this.left = true;
            this.right = false;
            this.anim.play("move");
        }
        else if (event.keyCode == cc.macro.KEY.right) {
            this.right = true;
            this.left = false;
            this.anim.play("move");
        }
        else if (event.keyCode == cc.macro.KEY.up) {
            this.up = true;
            this.down = false;
        }
        else if (event.keyCode == cc.macro.KEY.down) {
            this.down = true;
            this.up = false;
        }
    };
    Player.prototype.onKeyUp = function (event) {
        if (event.keyCode == cc.macro.KEY.right)
            this.right = false;
        else if (event.keyCode == cc.macro.KEY.left)
            this.left = false;
        else if (event.keyCode == cc.macro.KEY.up)
            this.up = false;
        else if (event.keyCode == cc.macro.KEY.down)
            this.down = false;
    };
    Player.prototype.reborn = function () {
        this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
        this.node.position = this.rebornPosition;
    };
    Player.prototype.lifecount = function () {
        this.lifect.getComponent("cc.Label").string = "LIFE" + this.life.toString();
        if (this.life == -1) {
            this.gameMgr.getComponent("GameManager").lose();
        }
    };
    Player.prototype.playerMovement = function (dt) {
        if (this.isDead) {
            this.playerSpeed = 0;
            this.left = false;
            this.right = false;
            this.up = false;
        }
        else {
            if (this.up && this.onGround) {
                //this.playerSpeed = 0;
                this.playerJump();
            }
            else if (this.left) {
                if (this.playerSpeed > 0) {
                    this.playerSpeed = -1;
                }
                else {
                    if (this.playerSpeed > -100) {
                        this.playerSpeed -= this.A * dt;
                    }
                    else {
                        this.playerSpeed = -100;
                    }
                }
            }
            else if (this.right) {
                if (this.playerSpeed < 0) {
                    this.playerSpeed = 1;
                }
                else {
                    if (this.playerSpeed < 100) {
                        this.playerSpeed += this.A * dt;
                    }
                    else {
                        this.playerSpeed = 100;
                    }
                }
            }
            else if (this.down) {
                this.playerSpeed = 0;
            }
            else {
                this.playerSpeed = 0;
            }
            this.node.x += this.playerSpeed * dt;
        }
    };
    Player.prototype.playerJump = function () {
        this.onGround = false;
        this.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 500);
        this.anim.play("jump");
    };
    Player.prototype.updateLife = function (num) {
        this.life += num;
        this.life = Math.min(Math.max(this.life, -1), 99);
        cc.log(this.life);
        if (this.life == -1) {
            cc.director.loadScene("lose");
        }
    };
    Player.prototype.playerRecover = function () {
        this.updateLife(1);
    };
    Player.prototype.playerDie = function () {
        this.updateLife(-1);
        if (this.life != -1) {
            this.reborn();
        }
    };
    Player.prototype.playerAnimation = function () {
        this.node.scaleX = (this.left) ? -1 : (this.right) ? 1 : this.node.scaleX;
    };
    Player.prototype.onBeginContact = function (contact, self, other) {
        if (other.node.name == "flag") {
            cc.director.loadScene("win");
        }
        else {
            // Mario on Top.
            if (contact.getWorldManifold().normal.y == -1) {
                if (other.tag == 1) {
                    this.onGround = true;
                }
                else if (other.tag == 2) {
                    this.isDead = true;
                    this.playerDie();
                }
                else if (other.tag == 3) {
                }
                else if (other.tag == 4) {
                    this.isDead = true;
                    this.playerDie();
                }
            }
            // Mario at Bottom.
            else if (contact.getWorldManifold().normal.y == 1) {
                if (other.tag == 1) {
                    this.onGround = true;
                }
                else if (other.tag == 2) {
                    this.isDead = true;
                    this.playerDie();
                }
                else if (other.tag == 3) {
                    this.isDead = true;
                    this.playerDie();
                }
                else if (other.tag == 4) {
                    this.isDead = true;
                    this.playerDie();
                }
            }
            // Left or Right direction.
            else {
                if (other.tag == 1) {
                    this.onGround = true;
                }
                else if (other.tag == 2) {
                    this.isDead = true;
                    this.playerDie();
                }
                else if (other.tag == 3) {
                    this.isDead = true;
                    this.playerDie();
                }
                else if (other.tag == 4) {
                    this.isDead = true;
                    this.playerDie();
                }
            }
        }
    };
    __decorate([
        property()
    ], Player.prototype, "playerSpeed", void 0);
    __decorate([
        property(cc.Node)
    ], Player.prototype, "gameMgr", void 0);
    __decorate([
        property(cc.Node)
    ], Player.prototype, "lifect", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Player.js.map
        