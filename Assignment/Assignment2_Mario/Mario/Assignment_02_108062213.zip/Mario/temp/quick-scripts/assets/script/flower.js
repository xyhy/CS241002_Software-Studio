(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/flower.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f141fhIwRNNoL+qTouuLRM+', 'flower', __filename);
// script/flower.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var turtle = /** @class */ (function (_super) {
    __extends(turtle, _super);
    function turtle() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null; //this will use to get animation component
        _this.animateState = null; //this will use to record animationState
        _this.rebornPos = null;
        return _this;
    }
    turtle.prototype.onLoad = function () {
        this.anim = this.getComponent(cc.Animation);
    };
    turtle.prototype.start = function () {
        this.rebornPos = this.node.position;
        this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 10);
        this.animateState = this.anim.play('Turtle_anim');
    };
    turtle.prototype.update = function (dt) {
        this.movement();
    };
    turtle.prototype.resetPos = function () {
        this.node.position = this.rebornPos;
        this.node.scaleX = 1;
        this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 10);
    };
    turtle.prototype.movement = function () {
        if (this.node.position.y < this.rebornPos.y) {
            this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 10);
        }
        else if (this.node.position.y > this.rebornPos.y + 40) {
            this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, -10);
        }
    };
    turtle.prototype.onBeginContact = function (contact, self, other) {
    }; // end onBeginContact.
    turtle = __decorate([
        ccclass
    ], turtle);
    return turtle;
}(cc.Component));
exports.default = turtle;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=flower.js.map
        