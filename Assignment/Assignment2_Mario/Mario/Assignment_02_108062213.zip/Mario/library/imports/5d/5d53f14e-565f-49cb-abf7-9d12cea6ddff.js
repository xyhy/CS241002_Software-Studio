"use strict";
cc._RF.push(module, '5d53fFOVl9Jy6v3nRLOpt3/', 'GameEngine');
// script/GameEngine.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameMgr = /** @class */ (function (_super) {
    __extends(GameMgr, _super);
    function GameMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.bgm = null;
        _this.timer = null;
        _this.camera = null;
        _this.background = null;
        _this.lowerbound = null;
        _this.life = null;
        _this.playerlife = 5;
        _this.time = 300;
        _this.pause = false;
        return _this;
    }
    GameMgr.prototype.onLoad = function () {
        this.life.y = this.timer.y;
    };
    GameMgr.prototype.start = function () {
        this.gameStart();
    };
    GameMgr.prototype.update = function (dt) {
        this.camera.x = this.player.x - 400;
        this.background.x = this.player.x;
        this.timer.x = this.background.x + 100;
        this.life.x = this.timer.x - 100;
        this.lowerbound.x = this.background.x;
    };
    GameMgr.prototype.updateHighestScore = function (score) {
    };
    GameMgr.prototype.updateScore = function (score) {
    };
    GameMgr.prototype.updateLife = function (num) {
        this.playerlife += num;
        this.playerlife = Math.min(Math.max(this.playerlife, -1), 99);
        if (this.playerlife == -1) {
            this.gameOver();
        }
    };
    GameMgr.prototype.timecount = function () {
        this.time -= 1;
        this.timer.getComponent("cc.Label").string = "TIME " + this.time.toString();
        if (this.time == 0) {
            this.gameOver();
        }
    };
    GameMgr.prototype.gameStart = function () {
        this.schedule(this.timecount, 1);
        cc.audioEngine.playMusic(this.bgm, true);
    };
    GameMgr.prototype.gamePause = function () {
        this.pause = !this.pause;
        if (!this.pause) {
            this.pause = true;
            this.scheduleOnce(function () {
                cc.game.pause();
            }, 0.1);
        }
        else {
            this.pause = false;
            cc.game.resume();
        }
    };
    GameMgr.prototype.lose = function () {
    };
    GameMgr.prototype.gameOver = function () {
        this.updateLife(-1);
    };
    GameMgr.prototype.gameEnd = function () {
        cc.game.end();
    };
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "player", void 0);
    __decorate([
        property({ type: cc.AudioClip })
    ], GameMgr.prototype, "bgm", void 0);
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "timer", void 0);
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "camera", void 0);
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "background", void 0);
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "lowerbound", void 0);
    __decorate([
        property(cc.Node)
    ], GameMgr.prototype, "life", void 0);
    GameMgr = __decorate([
        ccclass
    ], GameMgr);
    return GameMgr;
}(cc.Component));
exports.default = GameMgr;

cc._RF.pop();