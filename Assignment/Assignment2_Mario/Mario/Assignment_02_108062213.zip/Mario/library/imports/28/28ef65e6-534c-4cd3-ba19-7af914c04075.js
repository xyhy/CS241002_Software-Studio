"use strict";
cc._RF.push(module, '28ef6XmU0xM07oZevkUwEB1', 'mush');
// script/mush.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var turtle = /** @class */ (function (_super) {
    __extends(turtle, _super);
    function turtle() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null; //this will use to get animation component
        _this.animateState = null; //this will use to record animationState
        _this.rebornPos = null;
        _this.isDead = true;
        return _this;
    }
    turtle.prototype.onLoad = function () {
        this.anim = this.getComponent(cc.Animation);
    };
    turtle.prototype.start = function () {
        this.rebornPos = this.node.position;
        this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(-50, 0);
        this.isDead = false;
        this.animateState = this.anim.play('Turtle_anim');
    };
    turtle.prototype.update = function (dt) {
        if (this.isDead) {
            this.resetPos();
            this.isDead = false;
        }
        this.movement();
    };
    turtle.prototype.resetPos = function () {
        this.node.position = this.rebornPos;
        this.node.scaleX = 1;
        this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(-50, 0);
    };
    turtle.prototype.movement = function () {
        if (this.node.position.x < this.rebornPos.x - 100) {
            this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(50, 0);
        }
        else if (this.node.position.x > this.rebornPos.x + 100) {
            this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(-50, 0);
        }
    };
    turtle.prototype.onBeginContact = function (contact, self, other) {
        if (other.node.name == "player") {
            if (contact.getWorldManifold().normal.y == 1) { // Mario is on top of mushroom.
                this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
                this.isDead = true;
            }
            else {
                // Mario dead.
            }
        }
    }; // end onBeginContact.
    turtle = __decorate([
        ccclass
    ], turtle);
    return turtle;
}(cc.Component));
exports.default = turtle;

cc._RF.pop();