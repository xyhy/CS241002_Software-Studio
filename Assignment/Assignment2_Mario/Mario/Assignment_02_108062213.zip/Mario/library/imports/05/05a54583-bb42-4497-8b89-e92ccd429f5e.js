"use strict";
cc._RF.push(module, '05a54WDu0JEl4uJ6SzNQp9e', 'menu');
// script/menu.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var menu = /** @class */ (function (_super) {
    __extends(menu, _super);
    function menu() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    menu.prototype.onLoad = function () {
        this.button.node.on('click', this.callback, this);
    };
    menu.prototype.callback = function (button) {
        cc.director.loadScene("stage1-1");
    };
    __decorate([
        property(cc.Button)
    ], menu.prototype, "button", void 0);
    menu = __decorate([
        ccclass
    ], menu);
    return menu;
}(cc.Component));
exports.default = menu;
;

cc._RF.pop();